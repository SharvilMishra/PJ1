# Archive notes

This presentation archive contains the project source, documentation, dataset workbook, and catalog data. It excludes Git history, installed dependencies, build output, and the local `Frontend/.env` file. Prompt logs and generated output folders were not present in the project folder during packaging. Firebase configuration fields in the frontend are read from environment variables; fill them in locally from `Frontend/.env.example` before using Firebase features. No API key values or credentials are included.
